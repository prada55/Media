# MOTION STUDIO — Phase 7

## Nouveautés
- Images clés (keyframes) par clip.
- Propriétés animables : position X/Y, échelle, rotation et opacité.
- Ajout ou mise à jour d'une image clé à la position de la tête de lecture.
- Suppression d'une image clé à la position courante.
- Interpolation linéaire, douce (Ease In/Out) ou maintien (Hold).
- Liste des images clés et commande « Aller ».
- Affichage d'un indicateur ◆ sur les clips qui contiennent des images clés.
- Évaluation des valeurs animées pendant le déplacement de la tête de lecture et la lecture.
- Persistance des données d'animation dans le projet IndexedDB.

## Installation
1. Décompressez l'archive.
2. Remplacez les fichiers du dépôt GitHub Pages par le contenu du dossier.
3. Conservez la même adresse de site et ne supprimez pas les données Safari.
4. Attendez le déploiement puis rechargez Safari.

La base reste `motion-studio-db`, version 3. Les projets de la phase 6 sont normalisés à l'ouverture : chaque clip reçoit des valeurs de transformation et une liste de keyframes vide si nécessaire. Aucun magasin IndexedDB n'est supprimé.

## Utilisation
1. Ouvrez un projet et ajoutez un média sur la timeline.
2. Sélectionnez son clip.
3. Placez la tête de lecture à 0 seconde.
4. Réglez X, Y, échelle, rotation ou opacité.
5. Touchez « Ajouter / mettre à jour une image clé ».
6. Déplacez la tête de lecture plus loin dans le clip et modifiez une ou plusieurs valeurs.
7. Ajoutez une deuxième image clé.
8. Lancez la lecture ou déplacez la tête de lecture pour observer l'interpolation.
9. Choisissez Linéaire, Douce ou Maintenir avant de créer la clé ; pour changer une clé existante, placez la tête dessus puis modifiez le mode d'interpolation.

## Limites
- L'aperçu montre une carte graphique de démonstration transformée selon les valeurs interpolées ; il ne compose pas encore les pixels des vrais médias importés.
- Les propriétés sont stockées dans le repère de composition simplifié (X/Y en unités de composition, échelle en pourcentage).
- Les courbes Bézier éditables, les poignées de vitesse et le tracking automatique/manuel seront traités dans des phases dédiées.
- La synchronisation audio/vidéo et le rendu export final ne sont pas encore disponibles.
- Aucun test réel sur Safari iOS n'a été effectué depuis cet environnement.

## Vérifications conseillées
- [ ] Ouvrir un projet existant et vérifier ses clips.
- [ ] Créer un clip et sélectionner-le.
- [ ] Créer une première keyframe à 0 s.
- [ ] Créer une deuxième keyframe à 2 s avec une autre position/échelle.
- [ ] Tester Linéaire, Douce et Maintenir.
- [ ] Recharger Safari et vérifier que les keyframes sont conservées.
